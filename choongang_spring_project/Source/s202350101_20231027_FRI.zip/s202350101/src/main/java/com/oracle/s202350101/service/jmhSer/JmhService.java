package com.oracle.s202350101.service.jmhSer;

public interface JmhService {

}
