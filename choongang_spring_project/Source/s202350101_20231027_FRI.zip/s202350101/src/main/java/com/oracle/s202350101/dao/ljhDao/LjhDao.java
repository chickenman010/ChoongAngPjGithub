package com.oracle.s202350101.dao.ljhDao;

public interface LjhDao {

}
