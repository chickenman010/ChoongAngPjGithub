package com.oracle.s202350101.domain;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


//@Date 
@Getter
@Setter
@ToString
public class Code {
	private String table_name;
	private String field_name;
	private String cate_code;
	private String cate_name;

}
