package com.oracle.s202350101.service.cyjSer;

public class CyjServiceImpl implements CyjService {

}
