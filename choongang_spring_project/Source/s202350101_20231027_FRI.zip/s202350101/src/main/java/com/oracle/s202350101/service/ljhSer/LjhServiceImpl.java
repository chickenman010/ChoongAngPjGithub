package com.oracle.s202350101.service.ljhSer;

public class LjhServiceImpl implements LjhService {

}
