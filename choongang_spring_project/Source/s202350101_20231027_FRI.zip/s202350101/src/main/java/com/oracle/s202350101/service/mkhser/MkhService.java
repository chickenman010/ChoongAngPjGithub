package com.oracle.s202350101.service.mkhser;

public interface MkhService {

}
