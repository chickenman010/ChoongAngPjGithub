package com.oracle.s202350101.service.mkhser;

public class MkhServiceImpl implements MkhService {

}
