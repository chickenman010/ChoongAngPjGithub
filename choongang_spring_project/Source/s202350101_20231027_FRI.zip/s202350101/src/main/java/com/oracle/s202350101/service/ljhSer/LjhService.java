package com.oracle.s202350101.service.ljhSer;

public interface LjhService {

}
