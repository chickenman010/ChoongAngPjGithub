package com.oracle.s202350101.dao.ljhDao;

public class LjhDaoImpl implements LjhDao {

}
