package com.oracle.s202350101.dao.kjoDao;

public class KjoDaoImpl implements KjoDao {

}
